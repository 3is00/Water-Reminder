package com.example.waterreminder

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var perText: TextView
    private lateinit var goalInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressText = findViewById(R.id.progressText)
        progressBar = findViewById(R.id.progressBar)
        perText = findViewById(R.id.perText)
        goalInput = findViewById(R.id.goalInput)

        goalInput.setText(Store.goal(this).toString())

        findViewById<Button>(R.id.saveGoal).setOnClickListener {
            val ml = goalInput.text.toString().toIntOrNull()
            if (ml == null || ml < 500 || ml > 6000) {
                Toast.makeText(this, "اكتب رقم بين 500 و 6000 مل", Toast.LENGTH_SHORT).show()
            } else {
                Store.setGoal(this, ml)
                refresh()
            }
        }

        findViewById<Button>(R.id.drankBtn).setOnClickListener {
            Store.addDrank(this, Scheduler.perReminderMl(Store.goal(this)))
            refresh()
        }

        requestNotificationPermission()
        Scheduler.schedule(this)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val goal = Store.goal(this)
        val drank = Store.drankToday(this)
        val per = Scheduler.perReminderMl(goal)
        progressBar.max = goal
        progressBar.progress = drank.coerceAtMost(goal)
        progressText.text = "شربت $drank من $goal مل"
        perText.text = "كل تذكير (كل 30 دقيقة من 8 ص لـ 10 م): حوالي $per مل"

        val days = Store.lastDays(this, 7)
        findViewById<WeekChartView>(R.id.chart).setData(days, goal)
        val avg = days.sumOf { it.second } / days.size
        val hit = days.count { it.second >= goal }
        findViewById<TextView>(R.id.statsText).text =
            "المتوسط اليومي: $avg مل\nأيام حققت فيها الهدف: $hit من 7"
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
            )
        }
    }
}

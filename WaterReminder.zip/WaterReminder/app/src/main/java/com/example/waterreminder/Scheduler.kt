package com.example.waterreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import kotlin.math.roundToInt

object Scheduler {
    const val ACTION_REMIND = "com.example.waterreminder.REMIND"

    const val START_MIN = 8 * 60    // 08:00
    const val END_MIN = 22 * 60     // 22:00
    const val STEP_MIN = 30

    /** 08:00, 08:30, ... 22:00 -> 29 reminders per day. */
    fun slotsPerDay(): Int = (END_MIN - START_MIN) / STEP_MIN + 1

    /** Suggested amount per reminder, rounded to the nearest 10 ml. */
    fun perReminderMl(goalMl: Int): Int =
        ((goalMl.toDouble() / slotsPerDay() / 10).roundToInt() * 10).coerceAtLeast(10)

    /** The next reminder time strictly after [now]. */
    fun nextTrigger(now: Calendar): Calendar {
        val c = now.clone() as Calendar
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        val minOfDay = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val target: Int
        if (minOfDay < START_MIN) {
            target = START_MIN
        } else if (minOfDay >= END_MIN) {
            c.add(Calendar.DAY_OF_YEAR, 1)
            target = START_MIN
        } else {
            target = ((minOfDay - START_MIN) / STEP_MIN + 1) * STEP_MIN + START_MIN
        }
        c.set(Calendar.HOUR_OF_DAY, target / 60)
        c.set(Calendar.MINUTE, target % 60)
        return c
    }

    private fun pendingIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_REMIND)
        return PendingIntent.getBroadcast(
            ctx, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Schedules the single next reminder; the receiver schedules the one after it. */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = nextTrigger(Calendar.getInstance()).timeInMillis
        val pi = pendingIntent(ctx)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        if (canExact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(ctx))
    }
}

package com.example.waterreminder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/** Simple 7-day bar chart with a dashed goal line, drawn in a glassy style. */
class WeekChartView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var data: List<Pair<String, Int>> = emptyList()
    private var goal: Int = Store.DEFAULT_GOAL_ML

    private val d = resources.displayMetrics.density
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#26FFFFFF") }
    private val goalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B3FFFFFF")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(8 * d, 6 * d), 0f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 11 * d
    }

    fun setData(days: List<Pair<String, Int>>, goalMl: Int) {
        data = days
        goal = goalMl
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) return

        val labelH = 22 * d
        val topPad = 16 * d
        val chartH = height - labelH - topPad
        val maxVal = maxOf(goal, data.maxOf { it.second }).toFloat()
        val slot = width.toFloat() / data.size
        val barW = slot * 0.5f

        barPaint.shader = LinearGradient(
            0f, topPad, 0f, topPad + chartH,
            Color.WHITE, Color.parseColor("#7FDBFF"), Shader.TileMode.CLAMP
        )

        data.forEachIndexed { i, (label, ml) ->
            val cx = slot * i + slot / 2
            val track = RectF(cx - barW / 2, topPad, cx + barW / 2, topPad + chartH)
            canvas.drawRoundRect(track, 10 * d, 10 * d, trackPaint)

            val h = chartH * (ml / maxVal)
            if (h > 0f) {
                val bar = RectF(cx - barW / 2, topPad + chartH - h, cx + barW / 2, topPad + chartH)
                canvas.drawRoundRect(bar, 10 * d, 10 * d, barPaint)
            }
            canvas.drawText(label, cx, height - 6 * d, textPaint)
        }

        val gy = topPad + chartH * (1f - goal / maxVal)
        canvas.drawLine(0f, gy, width.toFloat(), gy, goalPaint)
    }
}

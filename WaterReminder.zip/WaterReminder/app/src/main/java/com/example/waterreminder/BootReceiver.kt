package com.example.waterreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-arms the reminder chain after reboot, app update or clock/timezone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.schedule(ctx)
    }
}

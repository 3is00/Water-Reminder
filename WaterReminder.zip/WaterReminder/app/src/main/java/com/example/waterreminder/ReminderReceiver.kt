package com.example.waterreminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Scheduler.ACTION_REMIND -> {
                // Always queue the next one first so the chain never breaks.
                Scheduler.schedule(ctx)
                showReminder(ctx)
            }
            ACTION_DRANK -> {
                Store.addDrank(ctx, Scheduler.perReminderMl(Store.goal(ctx)))
                NotificationManagerCompat.from(ctx).cancel(NOTIF_ID)
            }
        }
    }

    private fun showReminder(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "تذكير المياه", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(ch)
        }

        val goal = Store.goal(ctx)
        val per = Scheduler.perReminderMl(goal)
        val drank = Store.drankToday(ctx)

        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val drankIntent = PendingIntent.getBroadcast(
            ctx, 2,
            Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_DRANK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("وقت المياه 💧")
            .setContentText("اشرب حوالي $per مل — شربت النهاردة $drank من $goal مل")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "شربت", drankIntent)
            .build()

        try {
            NotificationManagerCompat.from(ctx).notify(NOTIF_ID, n)
        } catch (_: SecurityException) {
            // Notification permission not granted; nothing to show.
        }
    }

    companion object {
        const val CHANNEL_ID = "water_reminder"
        const val NOTIF_ID = 1001
        const val ACTION_DRANK = "com.example.waterreminder.DRANK"
    }
}

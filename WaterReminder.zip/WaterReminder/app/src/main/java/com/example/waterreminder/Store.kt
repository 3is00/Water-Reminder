package com.example.waterreminder

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** SharedPreferences wrapper: daily goal + per-day totals (history). */
object Store {
    private const val FILE = "water"
    private const val KEY_GOAL = "goal_ml"

    const val DEFAULT_GOAL_ML = 2500

    private val dayFmt = SimpleDateFormat("yyyyMMdd", Locale.US)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun key(cal: Calendar) = "d_" + dayFmt.format(cal.time)

    fun goal(ctx: Context): Int = prefs(ctx).getInt(KEY_GOAL, DEFAULT_GOAL_ML)

    fun setGoal(ctx: Context, ml: Int) {
        prefs(ctx).edit().putInt(KEY_GOAL, ml).apply()
    }

    fun drankToday(ctx: Context): Int = prefs(ctx).getInt(key(Calendar.getInstance()), 0)

    fun addDrank(ctx: Context, ml: Int) {
        val k = key(Calendar.getInstance())
        val p = prefs(ctx)
        p.edit().putInt(k, p.getInt(k, 0) + ml).apply()
    }

    /** Last [n] days, oldest first, as (short weekday label, ml). Today is last. */
    fun lastDays(ctx: Context, n: Int = 7): List<Pair<String, Int>> {
        val p = prefs(ctx)
        val labelFmt = SimpleDateFormat("EEE", Locale("ar"))
        val out = ArrayList<Pair<String, Int>>()
        for (i in n - 1 downTo 0) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -i)
            out.add(labelFmt.format(c.time) to p.getInt(key(c), 0))
        }
        return out
    }
}
